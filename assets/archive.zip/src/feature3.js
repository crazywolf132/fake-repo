// Feature 3 for octopus merge
function feature3() {
    return "Feature 3 implementation";
}

module.exports = { feature3 };